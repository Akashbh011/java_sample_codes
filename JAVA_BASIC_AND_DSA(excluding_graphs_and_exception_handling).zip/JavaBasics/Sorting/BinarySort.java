package Sorting;

public class BinarySort {
    public static void main(String[] args) {
        
    }
    
}
